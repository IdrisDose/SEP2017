# SEP2017
SEP Repo


# TODO
 - Update Colors
 - Update List pages towards a more album-like page (example; https://getbootstrap.com/docs/4.0/examples/album/)
